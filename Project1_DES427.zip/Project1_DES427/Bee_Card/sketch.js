var bee = {
  x: 200,
  y: 200,
  speed: 2, 
  
  displayBee: function () {
    
//BEE DRAW
    
    // Back wing
    fill('white');
    stroke('black');
    strokeWeight(2); 
    ellipse(this.x - 10, this.y - 37.5, 15, 40);

    // Body of the bee
    fill('yellow');
    circle(this.x, this.y, 50);
    
    // Stripes
    fill('black');
    strokeWeight(0.5);
    rect(this.x - 7, this.y - 25, 1, 50);
    rect(this.x - 1, this.y - 25, 1, 50);
    rect(this.x + 5, this.y - 25, 1, 50);
    
    // Stinger
     stroke('black');
    strokeWeight(2); 
    rect(this.x - 25, this.y + 1, -10, 1);


    // Draw the head of the bee
    fill('black');
    circle(this.x + 35, this.y, 27.5);

    // Draw the front wing
    fill('white');
    ellipse(this.x, this.y - 37.5, 15, 40);

    // Draw the bee's antennae
    line(this.x + 40, this.y - 10, this.x + 40, this.y - 35);
    line(this.x + 45, this.y - 10, this.x + 55, this.y - 30);
    
  },
  
  
//BEE MOVE
  
  moveBee: function () {
    var angle = atan2(mouseY - this.y, mouseX - this.x);
    this.x += cos(angle) * this.speed;
    this.y += sin(angle) * this.speed;
    
  }
  }

//IMAGE


var img;
function preload() {
  img = loadImage("Bee_Map.png");
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
    image(img, 0, 0, 400, 400);
  
bee.displayBee();
  bee.moveBee();
}